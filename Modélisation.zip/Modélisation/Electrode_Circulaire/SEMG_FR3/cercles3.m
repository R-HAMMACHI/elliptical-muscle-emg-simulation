%%%%%%%%%%%%%%%%%%%%%%%%%%%%% CERCLES %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Ce programme permet de faire la distribution des fibres
%% musculaires dans les unit�s motrices,  la distribution des longueurs  
%% associ�es aux fibres musculaires, la distribution des JNMs et les tendons 
%% droit et gauche, la distribution des unit�s motrices dans le muscle, 
%% La distribution des diam�tres des unit�s motrices la distribution des  
%% fr�quences de d�charges et la distribution des temps de recrutement des 
%% unit�s motrices
function[TREp,signaltot,xposi,yposi,LLLrepUnt,ISIREt] = cercles3(xxc,yyc,lonxx,lonyy,Nmuhv,nemb,longmoy,RR1,TMAX,tmp)
afch = 2;%% Le nombre des signaux MUAPTS et les UMs correspondantes affich�s 
%% Le nombre des unit�s motrices
Nmu=Nmuhv;
Rmuscle = 46;%%Le rayon du muscle
Ros = 20; %% Le rayon de l'os
epigress = Rmuscle + 3;%% 3 est l'�paisseur de la graisse
epipeau = epigress + 1;%% 1 est l'�paisseur de la peau
%ge = 0.75; %% 
MFR = 8;%% La fr�quence de d�charge minimale
PFRD = 10;
PFR1 = 30;
%%%%
ge =(PFR1-MFR)/(100-RR1);%On peut le changer
%%%%
%% Distribution des rayons des unit�s motrices selon la loi de Poisson
lambdar = 4; %% La valeur moyenne des diam�tres des unit�s motrices
range_r =(2:8); %% La gamme des diam�tres des unit�s motrices
a = min(range_r);%% La valeur minimale des diam�tres
b = max(range_r);%% La valeur maximale des diam�tres 
ll = 0;
ISIREt=[];
n = zeros(1,b-a+1);% touts les rayons
RR = [];
%yseed = nemb+3;%% Je change la distribution des diam�tres
%rand('seed',yseed);
while ll < Nmu
    R = poissrnd(lambdar);
    if (R <= b && R >= a)
        n(R-a+1) = n(R-a+1)+1;
        RR = [RR,R];
        ll = ll+1;
    end
end 
RR = sort(RR);
n;%% Le nombre des UMs avec les diff�rents diam�tres (a a+1 ...b)
T = 0:0.01:2*pi;%% Le p�rim�tre du muscle
xp = xxc + lonxx*cos(T);
yp = yyc + lonyy*sin(T);
xpl = Ros*sin(T);
ypl = Ros*cos(T);
figure
plot(Rmuscle*exp(1i*T),'k')
hold on;
axis equal;
plot(epipeau*exp(1i*T),'k'),plot(epigress*exp(1i*T),'k'),plot(xp,yp,'k'),fill(xpl,ypl,'c');
hold on; 
axis equal;
axis off;
%% Description de la densit� des fibres dans le muscle 
dens = 1; %% La densit� des fibres musculaires dans chaque unit� motrice
nbr=[];
for i=1:length(n)
    if n(i)~=0
       nbr(i) = dens*(pi*((range_r(i)/2).^2));
    else
        nbr(i) = 0;
    end
end
nbr = round(nbr);
%% Calcul des potentiels d'actions des unit�s motrices 
LLLT = [];%% Les signaux MUAPs
ZZ = [];
XXXX = [];
%% La position des unit�s motrices dans le muscle
xposi = [];
yposi = [];
j = 1;
%rand('seed',nemb+3); %% On peut changer la position de l'UM dans le muscle avec le changement de nemb
while j <= Nmu
    xxt = (xxc-lonxx)+2*lonxx*rand();
    yyt = (yyc-lonyy)+2*lonyy*rand();
    if (((xxt-xxc)/lonxx)^2+((yyt-yyc)/lonyy)^2<1&&sqrt(xxt^2+yyt^2)+RR(j)/2<=Rmuscle + 0.5&&sqrt(xxt^2+yyt^2)-RR(j)/2>=Ros)
        xposi = [xposi,xxt];
        yposi = [yposi,yyt];
        j= j + 1;
    end
end
scatter(xposi(1,:),yposi(1,:),2.5,'k','o','filled');
if nemb == 1
    title('Positions of the MUs Centers');
else
    title('Positions of the MUs Centers');
end
%% Les vitesses de conduction des unit�s motrices sont distribu�es selon la
%% loi de Gausse (Normale)
VV = [];
%yseed = nemb+7;%% Si on change yseed on change la distribution des vitesses
%randn('seed',yseed);
for j = 1:Nmu
    kl = 0;
    while kl~=1 
          v = normrnd(4,0.75,1,1);%% Distribution Gaussienne
        if v >= 2.5 && v <= 5.5 %% La gamme des vitesses des UMs
            kl = 1;
            VV = [VV, v];
        end
    end
end
%%
%rec = 0;%% Le nombre des unit�s motrices recrut�es
TT = linspace(0,40,128); %%40 temps L'intervalle de temps et le nombre de
HH = TT(2) - TT(1);%le pas du temps
RTE=exp(log(RR1)*(1:Nmu)/Nmu);
RP = 100;
TL = 90;
RT = 3;
P = exp(log(RP)*(1:Nmu)/Nmu);
past = 0.4883;%le pas de temps
temp=0:past:1000;%l'intervalle de temps de la premi�re minute
temp(1)=[];
IK = Nmu*log(0.1*temp)/log(RR1);
%IK=Nmu*log(0.1*temp)/log(RR1);
IK(IK<0)=0;
IK(IK>Nmu) = Nmu;%%%%%%%%
IK = fix(IK);
IK = [0,IK];IK(end)= Nmu;
temp = [0,temp];
%IK le nombre des unites motrices recrit�es a chaque instant t (temp)
%%%% temps de recr�tement de chaque unit� motrice%%%%%%%%%
init=[];
    for j=1:Nmu
        str=find(IK>=j);
        init = [init str(1)];
    end
% init le temps de recr�tement de chaque unit� k =init(k)*past
%%%les unites recrit� pour le temps tmp
rec = Nmu*log(100*tmp)/log(RR1);
%rec(rec<0)=0;

rec = min(fix(rec),Nmu);
       if tmp>=1
           rec=Nmu;
       end
%rec est le nombre desunites motrices recrit� pour le temps tmp
figure
plot(Rmuscle*exp(1i*T),'k')
hold on;
axis equal;
plot(epipeau*exp(1i*T),'k'),plot(epigress*exp(1i*T),'k'),plot(xp,yp,'k'),fill(xpl,ypl,'c');
hold on; 
axis equal;
axis off;
scatter(xposi(1,1:rec),yposi(1,1:rec),2.5,'k','o','filled');
if nemb == 1
    title('Positions of the MUs Centers recrit�es');
else
    title('Positions of the MUs Centers recrit�es');
end
%% Positions des unit�s motrices
figure 
plot(Rmuscle*exp(1i*T),'k')
hold on;axis equal;
plot(epipeau*exp(1i*T),'k'),plot(epigress*exp(1i*T),'k'),fill(xpl,ypl,'c')
hold on; 
axis equal;
axis off;
for j = 1:rec
    x = xposi(j);
    y = yposi(j);
    Distrad = sqrt(x^2+y^2);
    Zmu = (x+1i*y) + RR(j)*exp(1i*T)/2;
    ZZ = [ZZ,[x;y]];
    X = x;%% La position de l'unit� motrice selon l'axe r
    Y = y;%% La position de l'unit� motrice selon l'axe theta
    %% Les longueurs des fibres situ�es dans les unit�s motrices
    if nemb == 1
        title('Distribution of the MUs and the MFs')
    else
        title('Distribution of the MUs and the MFs')
    end
    [Long,Jnm,XXX] = fibro(nbr(RR(j)-a+1),RR(j),Zmu,X,Y,a,b,afch,j,longmoy,nemb);
    L1 = (Long/2) - Jnm;%% Semi-longueur droit des fibres 
    L2 = (Long/2) + Jnm;%% Semi-longueur gauche des fibres 
    %% Simulation des potentiels d'actions des unit�s motrices: c'est la
    %% somme des potentiels d'actions des fibres musculaires
    LL = 0;
        %% points du signal SFAP peuvent etre chang�
    %% Le nombre des figures affich�es doit etre inf�rieur ou �gale le 
    %% nombre des unit�s motrices j <= afch
    if j <= afch
        XXXX = [XXXX,XXX];
    end

%% Les signaux MUAPs sont les sommes des signaux SFAPs
    for l = 1:length(Long)
        %% La fonction qui calcul le potentiel d'une fibre musculaire
        %% ************ Cas d'un Volume Conducteur Planaire *********** %%
        LL = LL + SF(L1(l)*0.001,L2(l)*0.001,Jnm(l)*0.001,v,(Rmuscle-Distrad)*0.001).'; %% Source Analytique
        %LL = LL + (SF((Rmuscle-Distrad)*0.001) .');%% Source Impulsionnelle
        %% ********** Cas d'un Volume Conducteur Cylindrique *********** %%
        %LL = LL + SFAP_Limb(L1(l),L2(l),Jnm(l),v,Distrad).'; 
    end
        %force=exp(log(100)/Nmu*j);
        %seuil = exp(log(30)/Nmu*j);%% Le seuil de recrutement de toutes les unit�s motrices
        %E = linspace(0,100,Nmu);
         LLLT = [LLLT;P(j)*LL];%% C'est la matrice de sauvegarde des MUAPs
end
%% Simulation des trains de MUAPs et le signal EMG g�n�r� par le muscle
%pas = length(TT);
signaltot = 0;
%% Les Repr�sentations graphiques 
figure
 do = 0;
 ss = 1;
     for k = 1:afch
     subplot(afch,2,ss); plot(TT,real(LLLT(k,:)),'k'),
     if nemb == 1
         title('The MUAP')
     else
         title('The MUAP')
     end
     subplot(afch,2,ss+1);
     hold on;
     axis equal; 
     plot(ZZ(1,k)+1i*ZZ(2,k)-RR(k)*exp(1i*T)/2,'k');
     scatter(XXXX(1,do+1:do+nbr(RR(k)-a+1)),XXXX(2,do+1:do+nbr(RR(k)-a+1)),2,'k','o','filled');
     %% Ici 2.5 est consid�r� comme les rayons des fibres et on peut les 
     %% changer selon les besoins et la qualit� de la figure 
     do = do + nbr(RR(k)-a+1);
     if nemb == 1
         title('The Corresponding MU');
     else
         title('The Corresponding MU');
     end
     ss = ss + 2;
     end
%% La distribution des fr�quences de d�charges selon la loi de Poisson
%% Les temps d'activation des unit�s motrices sont distribu�es selon la loi 
%% uniforme (Distribution Uniforme)
%l1 = 0;
%lambdafr = 12;%% La valeur moyenne des fr�quences de d�charges 
%yseed = nemb+6;
%rand('seed',yseed); %% Si je veu changer la distribution des fr�quences je change yseed
%fr�cqueces max
%rand('seed',nemb+4); %% Si je veu changer le temps de d�part je change 8
TST=TL*(1./P).^(log(RT)/log(RP));
%indd = round((TST(k)/HH));
%% L'axe de temps des trains de potentiels d'actions des unit�s motrices
%% Repr�sentation graphique des signaux MUAPs et MUAPTs
figure
ss = 1;
do = 0;
LLLrepUnt = [];
%LLD =[];
%FR= round(FR);
%TEMP=0:past:TMAX*1000;
%logt=length(TEMP);
CV = 0.2; %% Constante de variation des ISIs
KUR = [];
DT = [];
LLLrepp = [];
lgt = TMAX*1000/past+1;
for k = 1:rec
%% Le signal MUAP doit etre r�p�ter fr fois ou ce qu'on appelle Train de
%% potentiel d'action d'une unit� motrice       
%% Les s�parations entre les impulsions se faitent par des z�ros %%%%%%%%%
%% MU(FR(k))=((125-0.05)/(FRmin-FRmax))*(FR(k)-FRmin)+125 (c'est la
%% Relation de calcul de la fr�quence suivante  
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%% les ISI%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%randn('seed',k+1);
   LLLrep=[zeros(1,init(k)-1)];
   if k==1||k==fix(k/10)*10
   DT=[DT,[length(LLLrep)*past;k]];
   end
 ISIS=[];
       if k==Nmu
            PFRi = PFR1;
       else
           PFRi = PFR1-PFRD*RTE(end-k+1)/RTE(end);
       end
  while length(LLLrep)<lgt
 %%%%%%La fr�quance instantan� de chaque unit� motrice %%%%%%%%%%%%%%%%%%%%
      Et = min((length(LLLrep)-1)*past*0.1,100*tmp);             
      FR = ge*(Et-RTE(k))+MFR ;
                 if FR < MFR
                   FR = MFR;
                 elseif FR > PFRi
                   FR = PFRi;
                 end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
       Z = normrnd(0,1);
%%%%%%%%%% Z est choisie dans lintevalle [-3.9 3.9] %%%%%%%%%%%%%%%%%%%%%%%
       if Z<-3.9
           Z=-3.9;
       elseif Z>3.9
           Z=3.9;
       end
       ISI = 1000*(1+CV*Z)/FR;
       ns = fix(ISI/past)+1;
 %%%%%%%%%%%%%%        %%%%%%%%%%%%%%%         %%%%%%%%%%%%%   %%%%%%%%%%%%
                %xx=((127*HH)/((ns-1)*past))*(0:(ns-1))*past;
                %yy = spline(TT,LLLT(1,:),xx);
%%%%%%%%%%%%%%        %%%%%%%%%%%%%%%          %%%%%%%%%%%%%   %%%%%%%%%%%%
                xx= 0:past:(127*HH);
                yy = spline(TT,LLLT(1,:),xx);
                if ISI<=127*HH
                ISI=127*HH;
                else
                yy(ns)=0;
                end
                %yy = interp1(TT,LLLT(k,:),xx);              
         LLLrep = [LLLrep,yy];
         
         if k==1||k==fix(k/10)*10
         DT=[DT,[(length(LLLrep)-1)*past;k]];
         end
 
      ISIS=[ISIS,ISI];
  end
      
              ddim=size(ISIREt);
              if ddim(2)>length(ISIS)&& k~=1
              ISIS(ddim(2))=0;
              elseif ddim(2)<length(ISIS)&& k~=1
              ISIREt(1,length(ISIS))=0;
              end
              ISIREt=[ISIREt;ISIS];
      
  LLLT(1,:)=[];
  %if k==2
  %figure
  %plot(0:past:(length(LLLrep)-1)*past,real(LLLrep))
  %KUR_SEMG = abs(kurtosis(LLLrep));
 % end
%% Chaque MUAPT doit etre d�caler avec une dur�e TST (pour dire que 
%% le recrutement des unit�s motrices est dynamique)
%LLLrep = [zeros(1,indd+1),LLLrep];
%% LLLrep est le vecteur du train de MUAP de chaque unit� motrice
%% LLLrep est le vecteur Y et TREp est l'axe des X  
%% Si le nombre des unit�s motrices est petit je vais afficher les 
%% diff�rents trains des signaux des unit�s de ce muscle
%% Touts les trains des potentiels d'action des unit�s motrices seront
%% sauvegard�s dans une matrice appel� LLLrepUnt o� chaque ligne 
%% repr�sente un train de MUAP et pour obtenir ce signal on �crit 
%% LLLrepUnt(k,1:length(LLLrep))son vecteur x est TREp et son vecteur Y 
%% est:LLLrepUnt(20,1:length(LLLrep))Pour ploter on peut �crire: 
%% plot(TREp,LLLrepUnt(k,1:length(LLLrep)))
% a2 = size(LLLrepUnt);
% b2 = length(LLLrep);
% if b2 > a2(1,2)&& k~=1
%    LLLrepUnt = [LLLrepUnt ,[zeros(a2(1,1),b2 - a2(1,2))]];
% elseif b2<a2(1,2)&& k~=1 
%    LLLrep= [LLLrep ,[zeros(1,a2(1,2)-b2)]];
% end 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% b3 = length(signaltot);
% b2 = length(LLLrep);
% if b3>b2 && k~=1
% LLLrepUnt(1,b3) = 0;
% LLLrep(b3) = 0;
% elseif b3<b2 && k~=1 
% signaltot(b2) = 0;
% end 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
LLLrep=LLLrep(1:lgt);
if k==1||k==fix(k/10)*10
LLLrepUnt = [LLLrepUnt;LLLrep]; %% La matrice des signaux MUAPTs
end
if k <= afch
    LLLrepp=[LLLrepp;LLLrep];% pour affichage seulement
%LLD = [LLD,length(LLLrepUnt)];
%TREp = linspace(0,(length(LLLrep)-1)*HH,length(LLLrep));
TREp = (0:(lgt-1))*past;
%TREp = linspace(0,1000,length(LLLrep));
subplot(afch,2,ss); plot(TREp,real(LLLrep),'k'),
if nemb == 1
title('The MUAPT')
else
title('The MUAP')
end
subplot(afch,2,ss+1);
hold on;
axis equal;
fill(xpl,ypl,'c')
plot(ZZ(1,k)+1i*ZZ(2,k)-RR(k)*exp(1i*T)/2,'k');
plot(epipeau*exp(1i*T),'k')
plot(epigress*exp(1i*T),'k')
scatter(XXXX(1,do+1:do+nbr(RR(k)-a+1)),XXXX(2,do+1:do+nbr(RR(k)-a+1)),2,'k','o','filled');
axis equal;
hold on;
%% Ici 1.5 repr�sente les rayons des fibres et on peut les changer selon
%% les besoins et selon la qualit� d'affichage
do = do + nbr(RR(k)-a+1);
plot(Rmuscle*exp(1i*T),'k')
if nemb == 1
title('The Position of the Corresponding MU');
else
title('The Position of the Corresponding MU');
end
ss = ss + 2;
end
%% Le signal EMG de surface est la somme de toutes les trains des
%% potentiels d'actions des unit�s motrices actives (MUAPTs)
signaltot = signaltot + LLLrep;
KUR = [KUR abs(kurtosis(signaltot))];
end
%% Repr�sentation Graphique des trains de MUAP et les positions de ses unit�s motrices
figure
do = 0;
ss = 1;
for k = 1:afch
    %TREp = linspace(0,(length(LLLrep)-1)*HH,length(LLLrepUnt));
   subplot(afch,2,ss); plot(TREp,real(LLLrepp(k,:)),'k'),
if nemb == 1
title('The MUAPT')
else
title('The MUAPT')
end
subplot(afch,2,ss+1);
hold on;
axis equal;
plot(ZZ(1,k)+1i*ZZ(2,k)-RR(k)*exp(1i*T)/2,'k');
scatter(XXXX(1,do+1:do+nbr(RR(k)-a+1)),XXXX(2,do+1:do+nbr(RR(k)-a+1)),2,'k','o','filled');
hold on
%% Ici 2.5 repr�sente les rayons des fibres et on peut les changer
%% Selon les besoins et la qualit� d'affichage
do = do + nbr(RR(k)-a+1);
if nemb == 1
title('The Corresponding MU');
else
title('The Corresponding MU');
end
ss = ss + 2;
end
%% Repr�sentation graphique du signal EMG mod�lis�
figure
plot(TREp,real(signaltot))
if nemb == 1
title('Surface EMG Signal')
else
    title('Surface EMG Signal')
%title(['Le signal SEMG pour ' num2str(tmp) 'secoundes d''enregistrement'])
%title('Surface EMG Signal (Muscle 2)')
end
figure
hold on;
axis equal;
axis off;
plot(Rmuscle*exp(1i*T),'k')
fill(xpl,ypl,'c')
plot(epipeau*exp(1i*T),'k')
plot(epigress*exp(1i*T),'k')
for k = 1:rec
plot(ZZ(1,k)+1i*ZZ(2,k)-RR(k)*exp(1i*T)/2,'k');
end
if nemb == 1
title('Positions of the MUs Territories');
else
title('Positions of the MUs Territories');
end
%% Param�tres importants dans la mod�lisation du signal EMG de surface
Les_diameres_des_unites_motrices = range_r
Le_nombre_des_unites_motrices_selon_ses_diametres = n
Le_nombre_des_fibres_dans_les_unites_selon_ses_diametres = nbr
Le_nombre_totale_des_fibres_dans_le_muscle = sum(n.*nbr)
Le_vecteur_de_la_vitesse = VV
% if nemb == 1                                                                    
% Le_nombre_des_UMs_recrutes_dans_le_premier_muscle = rec
% else
% Le_nombre_des_UMs_recrutes_dans_le_deuxieme_muscle = rec
% end
Les_diametres_des_UMs = RR
%Le_Temps_de_Recrutement_des_UMs = TST
%% **************************************************************** %%%% 
%LLLTT = linspace(0,(length(LLLrep)-1)*HH,length(LLLrepUnt));
%LLLrepUntt = LLLrepUnt(1:min(4,1),:);
%% Le nombre de fois de r�p�tition du signal total
%  rep = 1;%% On peut changer le nombre de r�p�titions du signal EMG
%  ii = 1;
%  while signaltot(ii)==0
%      ii = ii + 1;
%  end
%  ii = ii-1;
%  ll = length(signaltot);
% aa = max(TREp)+TT(2)-TT(1);
% bb = aa +(ll-ii+1)*(TT(2)-TT(1));
% TF = TREp;
% YF = signaltot;
%  for jj=2:rep
%      TF=[TF,linspace(aa,bb,ll-ii+1)];
%      YF=[YF,signaltot(ii:ll)];
%      aa=max(bb)+TT(2)-TT(1);
%      bb=aa+(ll-ii+1)*(TT(2)-TT(1));
%  end    
% figure
% plot(TF,real(YF))
% if nemb == 1
% title('Surface EMG Signal (Muscle 1) Repeated')
% else
% title('Surface EMG Signal (Muscle 2) Repeated')
% end
%% Le signal total pour une dur�e d'une minute %%%%%%%%%%%%
% figure
% plot((0:(length(signaltot)-1))*past,real(signaltot))
% if nemb == 1
% title('Surface EMG Signal (Muscle 1) in a one Minut')
% else
% title('Surface EMG Signal (Muscle 2) in two Minuts')
% end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
Le_pas_du_vecteur_temps = past;
Les_frequences_de_decharge = FR;
%La_longueur_du_vecteur_signal_total_en_une_minute = fix(1000/HH)+1;
%La_duree_totale_du_signal=(length(signaltot)-1)*HH;
le_nombre_des_unites_motrices_recrites=rec
figure
plot(KUR)
title('Variation du Kurtosis du signal SEMG en fonction du nombre d''UMs recrit�es')
figure
stem(1:rec,past*(init(1:rec)-1),'fill','.r')
title('L''instant de recrutement de chaque unit� motrice recrit�')
ylabel('temps [ms]')
xlabel('le numero de l''unit�')
figure
stem(1:Nmu,min((init(1:Nmu)-1)*past*0.1,100*tmp),'fill','.r');
hold on
stem(1:Nmu,RTE,'--ob');
legend('E(t)','RTE',2)
title('E(t)� l''intant de recrutement de chaque unit� motrice')
ylabel('pourcentage %')
xlabel('le numero de l''unit�')
figure
plot(TREp,min(TREp*0.1,100*tmp),'r')
title('E(t) en fonction de temps')
xlabel('temps [ms]')
ylabel('%')

figure
ind=find(IK==rec);
ind=ind(1);
plot([temp(1:ind) temp(end)+200],[IK(1:ind) IK(ind)])
title('Le nombre des unit�s motrices recrut�s en fonction du temps')
xlabel('temps [ms]')
ylabel('le nombre des unit�s motrices recrut�s')
figure
p=DT(1,:)<=TMAX*1000;
plot(DT(1,p),DT(2,p),'+')
hold on
plot(0,0)
for k=0:10:rec
    plot([0 TMAX*1000],[max(1,k) max(1,k)],'r')
    text(TMAX*1000+2,max(1,k),['UM' num2str(max(1,k))])
end
plot(0,rec+4)
set(gca,'YTick',[])
xlabel('temps [ms]')
title('Le temps des d�charges des UMs et les ISIs')
figure

for i=0:10:rec
    subplot((fix(rec/10))+1,1,fix(i/10)+1)
    plot(TREp,real(LLLrepUnt(fix(i/10)+1,:)))
    set(gca,'xtick',[],'ytick',[])
    text(TMAX*1000,0,['UM' num2str(max(1,i))])
end
FFRRY=[];
FFRRX=[];
xy1=0;
for k=1:rec
       if k==Nmu
            PFRi = PFR1;
       else
           PFRi = PFR1-PFRD*RTE(end-k+1)/RTE(end);
       end
    xy=(PFRi-MFR)/ge+RTE(k);
    xy1=max(xy1,xy);
    FFRRY=[FFRRY [MFR;PFRi;PFRi]];
    FFRRX=[FFRRX [RTE(k);xy]];
end
if xy1<100
    xy1 = 100;
end
figure
plot([FFRRX ;xy1*ones(1,rec)],FFRRY)
title('frequences')
xlabel('Et %')
ylabel('FREQUENCE HZ')
xlim ([0 100]);
ylim ([MFR PFR1+2]);
end                                                                        