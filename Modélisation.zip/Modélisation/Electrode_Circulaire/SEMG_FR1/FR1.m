
for Et2 = 10:10:100
    ellipse;
    save(['C:\Ascii_Gauss_Circ\SEMG_LSD_FR1_RR30%_PFR_20Hz_IED5mm_MVC' num2str(Et2)] ,'signaltot2','-ascii');
end