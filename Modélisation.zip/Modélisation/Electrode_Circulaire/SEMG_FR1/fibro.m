%%%%%%%%%%%%%%%%% Distribution des Fibres musculaires %%%%%%%%%%%%%%%%%%%%%
%% Cette fonction permette de distribuer: les positions des 
%% fibres musculaires dans les unit�s motrices, les longueurs des fibres 
%% musculaires, les jonctions neuromusculaires et les tendons droit et 
%% gauche
function[Long,Jnm,XXX]= fibro(Nfib,Rmu,Zmu,X,Y,a,b,afch,jj,longmoy,nemb)
rfib = 0.046/2;%% Le rayon des fibres musculaires 
plot(Zmu,'k')
hold on; 
axis equal;
%axis off;
Long = [];
Jnm = [];
XXX = [];
%rand ('seed',jj + 5 + nemb);  
RHO = rand(1,Nfib);
%rand ('seed',jj + 10 + nemb);%% Si on change 2 la distribution des fibres va changer
THETA = rand(1,Nfib);
%% Distribution des longueurs des fibres musculaires %%%%%%%
%compt = nemb+2; %% Si je change compt la distribution des longueurs des fibres va changer
%randn('seed',compt);
%Long = normrnd(longmoy,1,1,Nfib);
%if all(Long >= 40 & Long <= 160)~=1
    %Long=[]
  for j = 1:Nfib
    kl = 0;
    while kl ~= 1
        lg = normrnd(longmoy,1,1,1);%% Distribution de Gauss (80 est la valeur moyenne)
        if lg >= 40 && lg <= 160 %% La gamme des longueurs des fibres
            kl = 1;
        end
    end
        Long = [Long,lg];%% Les longueurs des fibres de l'unit� motrice
  end
%end
%rand('seed', jj + 6 + nemb);%% Si je veut changer les positions des JNM je change 3
   %% La distribution des jonctions neuromusculaires et les tendons est
   %% uniforme (la loi uniforme)
Jnm = (-5+(5)*rand(1,Nfib));%% Les jonctions des fibres des unit�s
%rand('seed',yseed);%% Pour fixer la distribution des fibres 
for j = 1:Nfib
    r = (Rmu/2+0.01)*RHO(j);%erreur=0.01
    thta = 2*pi*THETA(j);
    x = X + r*cos(thta);%% Position de la fibre selon l'axe x
    y = Y + r*sin(thta);%% Position de la fibre selon l'axe y
   %% 10 mm est la largeur de la zone d'�nervation et les zones tendineuses 
%% Pour afficher les fibres sans symboles, on peut enlever la partie
%% ci-dessous et on la remplacer par **
scatter(x,y,1.8,'k','o','filled');%% 1.8 repr�sente la taille des fibres
if jj <= afch
    XXX = [XXX,[x;y]];
end
%% Affichage des fibres par diff�rents symboles
    %if b-a+1<=10
     %   if Rmu == a
      %      scatter(x,y,3.5,'r','+');%% Si la taille des symboles des 
      % fibres est grande ou petite en remplace 3.5 par une autre valeur 
      % superieur ou inferieur 
       % elseif Rmu==a+1
        %    scatter(x,y,3.5,'r','*');%% La meme chose pour 3.5
        %elseif Rmu==a+2
         %   scatter(x,y,3.5,'r','o');%% La meme chose pour 3.5
        %elseif Rmu==a+3
         %   scatter(x,y,3.5,'r','x');%% La meme chose pour 3.5
        %elseif Rmu==a+4
         %   scatter(x,y,3.5,'r','s');%% La meme chose pour 3.5
         %elseif Rmu==a+5
          %  scatter(x,y,3.5,'r','p');%% La meme chose pour 3.5
         %elseif Rmu==a+6
          %  scatter(x,y,3.5,'r','v');%% La meme chose pour 3.5
         %elseif Rmu==a+7
          %  scatter(x,y,3.5,'r','h');%% La meme chose pour 3.5
         %elseif Rmu==a+8
          %  scatter(x,y,3.5,'r','d');%% La meme chose pour 3.5
         %elseif Rmu==a+9
          %  scatter(x,y,3.5,'r','^');%% La meme chose pour 3.5
end
    %else
     %     scatter(x,y,3.5,'r','o');%% La meme chose pour 3.5
    end
%end
    
    
    
    
