
for Et2 = 10:10:100
    ellipse;
    save(['E:\Ascii_Gauss_Rect\SEMG_LSD_FR3_RR30%_PFR_20Hz_IED5mm_MVC' num2str(Et2)] ,'signaltot2','-ascii');
end