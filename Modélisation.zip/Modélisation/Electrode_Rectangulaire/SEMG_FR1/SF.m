%% Cette fonction a pour objectif est de mod�liser le potentiel d'action 
%% g�n�r� par une seule fibre musculaire SFAP qui est une fonction des 
%% param�tres anatomiques et physiologiques d'un volume conducteur planaire
%% et ainsi des param�tres du syst�me de d�tection
function SFAP = SF(L1,L2,zi,v,y0)
%% D�finition des param�tres de la fonction
%% L1: c'est le demi longueur gauche de la fibre
%% L2: c'est le demi longueur droit de la fibre
%% zi: c'est la position de la jonction neuromusculaire
%% v: c'est la vitesse de conduction
%% y0: c'est la profodeur de chaque fibre musculaire
%% La fonction de transfert du volume conducteur planaire
%% Les param�tres Anatomiques 
h1 = 0.003; %% L'�paisseur de la couche de la graisse
d = 0.001; %% L'�paisseur de la couche de la peau 
%% Les param�tres Physiologiques
Ra = 5; %% Rapport des conductivit�s Longitudinal et Transversal du Muscle 
Rc = 20; %% Rapport des deux conductivit�s de la peau et de la graisse
Rm = 0.5; %% Rapport des conductivit�s transversal du muscle et de graisse 
sigmaT = 0.1; %% La conductivit� transversale du muscle 
%% Les fr�quences Angulaires Spatiales  
fx = (-256:2*2.005:256);%% en m^-1 
fz = (-256:2*2.005:256);%% en m^-1;
Kx = 2*pi*fx;
Kz = 2*pi*fz;
[Kx,Kz]= meshgrid(Kx,Kz);
%% Les diff�rentes Expressions
Ky = sqrt(Kx.^2 + Kz.^2);
Kya = sqrt(Kx.^2 + (Ra*(Kz.^2)));
s1 = Ky*(h1+d);
s2 = Ky*(h1-d);
alphas1 = Kya + Rm*(s1*tanh(s1));
alphas2 = Kya + Rm*(s2*tanh(s2));
FTmfs1 = (2/(sigmaT))*exp(-Kya*abs(y0));
FTmfs2 =((1+Rc)*cosh(s1)*alphas1)+((1-Rc)*cosh(s2)*alphas2);
FTvc_mfs = (FTmfs1)./(FTmfs2);
%% La Fonction de Transfert du Syst�me de D�tection
%% La fonction de transfert des �lectrodes de forme circulaire
a = 0.01; b = 0.001;
teta_deg = 0;%% Angle d'inclinaison du syst�me de d�tection
teta_rad = (teta_deg*pi)/(180);%% Il faut utiliser l'angle d'inclinaison en radian
Kx1 = Kx*cos(teta_rad) - Kz*sin(teta_rad); 
Kz1 = Kx*sin(teta_rad) + Kz*cos(teta_rad);
FTsizer = sinc((Kx1*a)/(2*pi)).*sinc((Kz1*b)/(2*pi));
%% La fonction de transfert du syst�me de d�tection 
%% Les poids donn�es aux �lectrodes
%% Les configurations Longitudinales des filtres spatiaux 
W = [0 1 0;0 -1 0;0 0 0];%%%%%(LSD)
%W = [0 1 0;0 -2 0;0 1 0];%%%%%(LDD)
%W = [0 1 0;1 -4 1;0 1 0];%%%%%(NDD)
%W = [1 1 1;1 -8 1;1 1 1]; %%%%%(IR)
%W = [1 2 1;2 -12 2;1 2 1];%%%%%(IB2)
%W = [8 3 2;-21 -3 0;7 2 2];%%%%%(MKF)
%W = [0 0 0;0 1 0;0 0 0];%%%%%(MNP)
%% ******************************************* %% 
%% Les configurations transversales des filtres spatiaux 
%W = [0 0 0;1 -1 0;0 0 0];%%%%%(TSD)
%W = [0 0 0;1 -2 1;0 0 0];%%%%%(TDD)
%W = [0 0 0; 1 -2 1; 1 -2 1];%%%%%(BiTDD)
%% Les distances inter�lectrodes
dx = 0.005;  
dz = 0.005; 
%% Expression de la Fonction de Transfert du Syst�me de D�tection
FTele = 0;
for s = -1:1;
    for r = -1:1;
          FTele = FTele + W(s+2,r+2).*(FTsizer).*(((exp(-1i*Kx1*s*dx)).*(exp(-1i*Kz1*r*dz))));
   end
end
%% La fonction de transfert des syst�mes en anneaux concentr�s
%% Les param�tres de la fonction
%% Les rayons des diff�rents anneaux
%r1 = 0.005; r2 = 0.01; r3 = 0.015;
%% Les poids donn�es aux �lectrodes
%% 1. Les poids donn�s aux �lectrodes pour un seul anneau 
%K0 = 1;K1 = -1;
%% 2. Les poids donn�s aux �lectrodes pour deux anneaux 
%K0 = 3; K1 = -4; K2 = 1;
%% 3. Les poids donn�s aux �lectrodes pour trois anneaux
%K0 = 10; K1 = -15; K2 = 6;K3 = -1;
%% La fonction de transfert pour un seul anneau avec une �lectrode ponctuel
%FTringK1 = K0 + K1*besselj(0,r1*sqrt(Kx1.^2 + Kz1.^2));
%FTring = FTringK1;
%% La fonction de transfert pour deux anneaux avec une �lectrode ponctuel
%FTringK2 = K0 + K1*besselj(0,r1*sqrt(Kx1.^2+Kz1.^2)) + K2*besselj(0,r2*sqrt(Kx1.^2+Kz1.^2));
%FTring = FTringK2;
%% La fonction de transfert pour trois anneaux avec une �lectrode ponctuel
%FTringK3 = K0 + K1*besselj(0,r1*sqrt(Kx1.^2+Kz1.^2)) + K2*besselj(0,r2*sqrt(Kx1.^2+Kz1.^2)) + K3*besselj(0,r3*sqrt(Kx1.^2+Kz1.^2));
%FTring = FTringK3;
%% La Fonction de Transfert Globale 
FTglo = FTvc_mfs.*FTele;%% Pour les syst�mes classiques
%FTglo = FTvc_mfs.*FTring;%% Pour les syst�mes en anneaux
%% Le potentiel d'action dans le domaine spatial 2D
TFI2D = fftshift(ifft2(fftshift(FTglo)));
%figure (1)
%mesh (real(TFI2D))
%% Le potentiel dans le domaine spatial 1D

%% ************************************************************************
%% ************************************************************************
%% Configuration Longitudinale
SFAP_Impul = TFI2D(64,:);
SFAP = SFAP_Impul.'; 
%% Configuration Transversale
%SFAP_Impul = TFI2D(:,64);
%SFAP = SFAP_Impul; 
%figure (2)
%plot (real(SFAP_Impul))
%% ********************************************************************* %%
%% Le produit de la fonction de transfert globale avec le terme exponentielle
x0 = 0; %%% Le pas de d�placement longitudinal
FT2D = FTglo.*exp(1j*Kx1*x0);
%% Calcul du filtre spatial 1D B(Kz)
for n = 1:128
    BKz1(:,n) = (1/(2*pi)).*(cumtrapz(FT2D(:,n)))*4.01*2*pi; %%% Longitudinal
    %BKz1(n,:) = (1/(2*pi)).*(cumtrapz(FT2D(n,:)))*4.01*2*pi; %%% Transversal
end
BKz = BKz1(128,:); %% Longitudinal
%BKz = BKz1(:,128); %% Transversal
%% Calcul de la densit� de courant de la source
z = (-15:0.235:15)./1000; 
%% La premi�re d�riv�e du PAI
bcii_z = (-96.*exp(z)).*((3*(z).^2)+(z).^3);
%% La transform�e de Fourier de la premi�re d�riv�e
FT_bscii_Z = fftshift(fft(bcii_z));
%% Le conjugu� de la transform�e de Fourier de la premi�re d�riv�e 
Conj_FT_bscii_Z = conj(FT_bscii_Z);
Conj_FT_bscii_Z1 = (1/v).*Conj_FT_bscii_Z;
%% Calcul des deux fr�quences Kepsilon et Kbeta
ft = (0:2.36:300);
K_t = 2*pi*ft;
[K_t] = meshgrid(K_t);
K_epsilon = Kz + K_t/v;
K_beta = Kz - K_t/v;
%% La premi�re fonction de la source
I_KzKt1 = 1j.*Kz.*exp(-1j*Kz*zi);
%% La deuxi�me fonction de la source 
I_KzKt2 = ((exp(-1j.*K_epsilon.*(L1/2))).*(sin(K_epsilon.*(L1/2))./(K_epsilon/2)))-((exp(1j.*K_beta.*(L2/2))).*(sin(K_beta.*(L2/2))./(K_beta/2)));
%% La fonction globale de la transform�e de Fourier 2D de la source
I_KzKt = I_KzKt1.*I_KzKt2;
%% Le produit de TF 2D de la source et le filtre B(Kz)
%% ********************************************************************* %%
z0 = 0; %% Le pas de d�placement longitudinal
%% ********************************************************************* %%
Kz1D = 2*pi*fz;
TERM_EXP = exp(1j.*Kz1D.*z0);
%% BKz complet
BKZ_EXP = BKz.*TERM_EXP; %% Longitudinal
%BKZ_EXP = (BKz.').*TERM_EXP; %% Transversal

%% Le produit de la transform�e de Fourier de la source et le filtre BKz
for m = 1:128 
    Ai_Kt(:,m) = I_KzKt(:,m).*BKZ_EXP(m); 
end
%% Calcul de l'int�grale de la fonction Ai_Kt
for k = 1:128
    Int_Ai_Kt(:,k) = (1/(2*pi)).*cumtrapz(Ai_Kt(:,k))*8.05*2*pi; 
end  
for k = 1:128
    SFAP_Freq1 (k,:) = Conj_FT_bscii_Z1(k).*Int_Ai_Kt(k,:); 
end
SFAP_Freq = SFAP_Freq1(64,:); 
%% Calcul du signal SFAP
SFAP1 = fftshift(ifft(fftshift(SFAP_Freq)));
%SFAP = SFAP1.';

