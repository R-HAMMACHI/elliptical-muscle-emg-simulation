%%%%%%%%%%%%%%%%%%%%% Le Muscle de forme Elliptique %%%%%%%%%%%%%%%%%%%%%%%
%% L'objectif de ce programme est de simuler le signal EMG de surface
%% g�n�r� dans des muscles sous forme d'ellipces l'une horizontale et
%% l'autre verticale
%% D�but de l'ex�cution
tic; 
close all; 
%clear all; 
%clc;
T = 0:0.01:2*pi;%% Le p�rim�tre des diff�rents cercles 
%% Les param�tres anatomiques du volume conducteur (ces param�tres existent 
%% aussi dans le programme de la fonction cercles) donc chaque changement 
%% Ici doit etre faite dans le programme cercles
Rmuscle = 46; %% Le rayon du muscle
Ros = 20; %% Le rayon de l'os 
epigress = Rmuscle + 3; %% 3 Repr�sente l'�paisseur de la graisse
epipeau = epigress + 1; %% 1 Repr�sente l'�paisseur de la peau
%% Le premier muscle: Sa Position est Verticale (cot� cosinus) et on peut la changer
k1 = 0; %% Si on met k1=1 le muscle 1 sera active (si on met k1 = 0 le muscle 1 sera inactive) 
x1c = 33; %% La coordonn�e du centre de l'ellipse 1 (muscle 1) selon x
y1c = 0; %% La coordonn�e du centre de l'ellipse 1 (muscle 1) selon y
lonx1 = 13; %% Le demi-petit axe de l'ellipse (l'axe des x)
lony1 = 27; %% Le demi-grand axe de l'ellipse (l'axe des y)
Nmu1 = 0; %% Le nombre des unit�s motrices du premier muscle
longmoy1 = 130; %% La valeur moyenne des longueurs des fibres(grand muscle)
RR1 = 50; %% Le niveau de contraction du muscle 1 (MVC1)
Et1 = 50;
%% Le deuxieme  muscle: Sa Position est Horizontale (cot� sinus) et on peut la changer
k2 = 1;        %% Si k2 = 1 on active le muscle 2(si on met k2 = 0 le muscle 2 sera inactive)
x2c = 0;       %% L'abscisse du centre de l'ellipse (muscle 2) 
y2c = 34;      %% L'ordonn� du centre de l'ellipse (muscle 2) 
lonx2 = 15;    %% Le semi-grand axe de l'ellipse 2 (l'axe des x)
lony2 = 10;    %% Le semi-petit axe de l'ellipse 2 (l'axe des y)
Nmu2 = 4;      %% Le nombre des unit�s motrices dans le deuxi�me muscle
longmoy2 = 80; %% La valeur moyenne des longueurs des fibres(petit muscle)
RR2 = 30;      %% The recruitment range (<=50% c'est �troit recrutement et >=70% c'est large recrutement)  
TMAX2 = 5; % La dur�e maximale d'enregistrement du signal EMG en seconds
%Et2 = 10; % E(t)en pourcentage
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
tmp2 = Et2/100;% La dur�e de la rampe (0 < tmp2 < 1),tmp2 = 1 implique que toutes les unit�s motrices sont recrut�es(ici je peu changer le niveau de la contraction maximale)
%% Analyse et ex�cution des deux muscles    
if k1 == 1
disp('*** Veuillez attendre les r�sultats du premier muscle (Ellipse 1) ***')
[TREp1,signaltot1,xposi1,yposi1,LLLT1,LLLrepUnt1] = cercles(x1c,y1c,lonx1,lony1,Nmu1,1,longmoy1,MVC1,Et1);
TREp1; %% C'est le vecteur des abscisses du signal MUAPT et du signal EMG du premier muscle
TREp1 = TREp1.';
%save('E:\JBSPC\Time','TREp1','-ascii');
signaltot1; %% C'est le vecteur du signal EMG g�n�r� par le premier muscle 
signaltot1 = signaltot1.';
%save('E:\BSPC\SEMG_1RGs','signaltot1','-ascii');
xposi1;%% Ce sont les positions des axes des unit�s motrices du premier muscle selon l'axe des x
yposi1;%% Ce sont les positions des axes des unit�s motrices du premier muscle selon l'axe des y
LLLT1;%% Les Potentiels d'Action des Unit�s Motrices (MUAPs) 
radial1 = sqrt(xposi1.^2 + yposi1.^2);
radial1 = radial1(1:min(10,Nmu1));%% Pour afficher 10 distances radiales
profondeur1 = Rmuscle - radial1; %% Profondeur des unit�s motrices
%% Si on veut afficher le MUAP de la premi�re unit� motrice on fait: LLLT1(1,1:pas), 
%% la deuxi�me unit� motrice: LLLT1(1,pas+1:2*pas),la troisi�me unit� motrice: LLLT1(1,2*pas+1:3*pas)
%% et la quatri�me:LLLT1(1,3*pas+1:4*pas) avec pas = 128 (le nombres des
%% �chantillons du signal SFAP et MUAP
LLLrepUnt1; %% Les Trains des Potentiels d'Action des Unit�s Motrices (MUAPTs)  
%% Si on veut afficher le signal MUAPT de la premi�re unit� motrice par exemple on fait: LLLrepUnt1(1,:)
%% pour la deuxi�me unit� motrice on fait LLLrepUnt1(2,:),de la troisi�me unit� motrice on fait: 
%% LLLrepUnt1(3,:), de la quatri�mme on fait: LLLrepUnt1(4,:)
end
if k2 == 1
disp('*** Veuillez attendre les r�sultats du deuxi�me muscle (Ellipse 2)***')
[TREp2,signaltot2,xposi2,yposi2,LLLrepUnt2,ISZ] = cercles(x2c,y2c,lonx2,lony2,Nmu2,2,longmoy2,RR2,TMAX2,tmp2);
TREp2;%% C'est le vecteur des abscisses du signal MUAPT et du signal EMG de la deuxi�me muscle
TREp2 = TREp2.';
%save('E:\Ascii_TEST_Gaussianity\Time70MVC','TREp2','-ascii');
signaltot2;%% C'est le vecteur du signal EMG g�n�r� par la deuxi�me muscle
signaltot2 = signaltot2.';
%save('E:\Ascii_TEST_Gaussianity\SEMG_MKF_FR1_RR70%_MVC10%_PFR1_55Hz','signaltot2','-ascii');
xposi2;%% Ce sont les positions des axes des unit�s motrices de la deuxi�me muscle selon l'axe des x
yposi2;%% Ce sont les positions des axes des unit�s motrices de la deuxi�me muscle selon l'axe des y 
radial2 = sqrt(xposi2.^2 + yposi2.^2);
radial2 = radial2(1:min(10,Nmu2));%% Pour afficher 10 distances radiales
profondeur2 = Rmuscle - radial2;%% Profondeurs des unit�s motrices
%% Si on veut afficher le MUAP de la premi�re unit� motrice on fait comme suit LLLT2(1,1:pas), 
%% la deuxi�me unit� motrice: LLLT2(1,pas+1:2*pas),la troisi�me unit� motrice: LLLT2(1,2*pas+1:3*pas)
%% et la quatri�me:LLLT2(1,3*pas+1:4*pas) avec pas = 128 (le nombres de
%% �chantillons du signal SFAP et MUAP
LLLrepUnt2;%% Les signaux des quatre premiers MUAPTs des unit�s motrices 
end
%% Si on veut afficher le signal MUAPT de la premi�re unit� motrice par exemple on fait: LLLrepUnt2(1,:)
%% pour la deuxi�me unit� motrice on fait LLLrepUnt2(2,:),de la troisi�me unit� motrice on fait: 
%% LLLrepUnt2(3,:), de la quatri�mme on fait: LLLrepUnt2(4,:)
% figure
% hold on;
% axis equal;
% axis off;
% if k1 == 1
% xp1 = x1c + lonx1*cos(T);
% yp1 = y1c + lony1*sin(T);
% plot(xp1,yp1,'k'),scatter(xposi1(1,:),yposi1(1,:),2.5,'k','o','filled'),
% end
% if k2 == 1
% xp2 = x2c + lonx2*cos(T);
% yp2 = y2c + lony2*sin(T);
% plot(xp2,yp2,'k'),scatter(xposi2(1,:),yposi2(1,:),2.5,'k','o','filled'),
% end
% xpl = Ros*sin(T);
% ypl = Ros*cos(T);
% plot(Rmuscle*exp(1i*T),'k'),fill(xpl,ypl,'c'),plot(epipeau*exp(1i*T),'k'),plot(epigress*exp(1i*T),'k');
%% 2.5 Repr�sente la taille du centre de l'unit� motrice
% if k1 == 1 && k2 == 1
%     title('Distribution of the MUs axes Within the Two Muscles');
% else
%     title('Distribution of the MUs axes Within one Muscle');
% end
%% Fin de la partie mod�lisation
disp('*********** End of the Program Execution Thank You ****************')
%% Computation of the Histogram
%[y,x] = hist(real(signaltot1),15);
%[y,x] = hist(real(signaltot2),15);
%save('E:\Revision_Ascii\Bins_LSD_Alpha0','x','-ASCII');
%save('E:\Revision_Ascii\Hist_LSD_Alpha0','y','-ASCII');
%% Evaluation des quatre types de s�lectivit�s spatiales 
%% A. Evaluation des s�lectivit�s transversale et en Profondeur
%% A.1. Evaluation par mesure de l'amplitude
%Amp_max = max(signaltot2);
%Amp_min = min(signaltot2);
%Amp_EMG = abs(Amp_max-Amp_min);
%% A.2. Evaluation par Root Mean Square (RMS)
%RMS_SEMG =  abs(sqrt(sum(signaltot2.^2)*(1/length(signaltot2))));
%% A.3. Evaluation par Area Rectified Value (ARV)
%ARV_SEMG = ((1/length(signaltot2)).*sum(abs(signaltot2)));
%% B. Evaluation de la s�lectivit� longitudinale
%% B.1. Evaluation par le support Temporel
%% L'intervalle de d�finition du signal MUAP %%
%t=z./4000;%%% La dur�e totale du signal %%%
%t = TREp1;%% C'est la dur�e du signal EMG1
%t = TREp2;%% C'est la dur�e du signal EMG2
%% Calcul de l'intervalle de temps t_bar %%
%t_bar1 = sum((t.*(signaltot2.^2))); 
%t_bar2 = sum(((signaltot2.^2)));
%t_bar = sqrt(t_bar1/t_bar2); 
%% Le support teporel B_t 
%B_t = sum((((t-t_bar).^2).*(signaltot2.^2)));
%TS_SEMG = real(sqrt(B_t/t_bar2))
%% B.2. Evaluation par la longueur de la forme d'onde (waveform length)
%WL1 = 0;
%for i=1:length(signaltot2)-1;
 %   WL1 = WL1 + abs((signaltot2(i+1)-signaltot2(i)));
%end
%WL_SEMG = WL1;
%% B.3. The absolute value of the third moment 
%TM3 = abs((1/length(signaltot2))*(sum(signaltot2.^3)));
%TM3_SEMG = TM3;
%% C. Evaluation de la S�lectivit� Inclin�e
%% Computation of the mode
%MODE_SEMG = abs(mode(signaltot2));
%% Computation of the mean
MEAN_SEMG = abs(mean(signaltot2));
%% Computation of the variance
%VAR_SEMG = 35*abs(var(signaltot2));
%% Computation of the median
%MEDIAN_SEMG = abs(median(signaltot2));
%% Computation of the STD
%STD_SEMG = abs(std(signaltot2));
%% The Skewness
%SKEW_SEMG = abs(skewness(signaltot2));
%% The Kurtosis
KUR_SEMG = abs(kurtosis(signaltot2))
%% Computation of the power spectrum in the frequency domain
% fs = length(signaltot2);
% nfft = 512;
% FFT_SEMG = fft(signaltot2,nfft);
% frequency = fs*((0:nfft-1)/nfft);
% Power_SEMGF = (FFT_SEMG.*conj(FFT_SEMG))/nfft;
%figure (11)
%plot(frequency,Power_SEMGF);
%% Computation of the Power in the time domain
% N = length(signaltot2);
% Power_10 = abs((sum(signaltot2.^2))/(N));
% Power_70 = Power_10*(35);
%% Computation of the SSC
% Threshold = 1.e-23;
% ximoin1 = signaltot2(1:end-2);
% xi = signaltot2(2:end-1);
% xiplus1 = signaltot2(3:end);
% vec = (xi-ximoin1).*(xi-xiplus1);
% vecf = vec > Threshold;
% SSC = sum(vecf);
TL=90;
RT=3;
RP=100;
P=exp(log(RP).*(1:Nmu2)./Nmu2);
TST=TL*(1./P).^(log(RT)./log(RP));
temp=1:10:1000;
FORCE= [];
forcej=[];
sd=size(ISZ);
forceuj=[];
for t=temp
    force=0;
    for i=1:sd(1)
        
        ISZi=ISZ(i,ISZ(i,:)>0);
        gij=(1-exp(-2*(TST(i)./ISZi)))./(TST(i)./ISZi);
        tij=TST(i)+40+ISZi;
        Fi=gij*P(i)/TST(i)*exp(1-t/TST(i));
        forcejj=0;
        for j=1:length(tij)
            if t>tij(j)
               %force=force+Fi(j)*(t-tij(j));
               forcejj=forcejj+Fi(j)*(t-tij(j));
            end
            
        end
        if i==1||i==fix(i/10)*10
        forcej=[forcej;forcejj];
        end
        force=force+forcejj;
    end
    forceuj=[forceuj,forcej];
    forcej=[];
    FORCE=[FORCE force];
end
figure
plot(temp,FORCE,'r')
title('La force totale du muscle')
figure
plot(temp,forceuj')
l=[];
s=size(forceuj);
for i=0:(s(1)-1)
    if i==0
    l=[l ;'UM  ' num2str(1)];
    elseif i*10<100
    l=[l ;'UM ' num2str(i*10)];
    else
    l=[l ;'UM' num2str(i*10)];    
    end
end
legend(l)
title('Les forces des unit�s motrices avec un pas de 10')
% figure
% lg=fix(tmp*1000/(TREp2(2)-TREp2(1)))+1;
% plot(TREp2(1:lg),real(signaltot2(1:lg)))
toc;%% La fin de l'ex�cution